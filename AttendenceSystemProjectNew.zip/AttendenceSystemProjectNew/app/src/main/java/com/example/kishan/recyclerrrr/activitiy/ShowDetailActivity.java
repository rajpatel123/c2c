package com.example.kishan.recyclerrrr.activitiy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.kishan.recyclerrrr.R;

public class ShowDetailActivity extends AppCompatActivity {
    private TextView firstName, lastname, mobileNumber, email, message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_detail);

        firstName = findViewById(R.id.name);
        mobileNumber = findViewById(R.id.mobile);
        email = findViewById(R.id.email);
        message = findViewById(R.id.comment);


        Intent intent = getIntent();
        if (intent.hasExtra("name")) {
            String emailText = intent.getStringExtra("email");
            email.setText("Email : " + emailText);

            String firstname = intent.getStringExtra("name");
            String lastNametxt = intent.getStringExtra("lname");

            firstName.setText("Name : " + firstname + " " + lastNametxt);


            String phone = intent.getStringExtra("mobile");
            mobileNumber.setText("Phone Number : " + phone);


            String messagetxt = intent.getStringExtra("message");
            message.setText(messagetxt);


        }
    }
}
