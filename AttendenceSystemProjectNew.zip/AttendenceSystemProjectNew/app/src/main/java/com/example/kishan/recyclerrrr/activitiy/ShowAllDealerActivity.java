package com.example.kishan.recyclerrrr.activitiy;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.kishan.recyclerrrr.BuildConfig;
import com.example.kishan.recyclerrrr.R;
import com.example.kishan.recyclerrrr.adapter.DealerAdapter;
import com.example.kishan.recyclerrrr.modelClass.addagentbyid.GetDealerByIdResponse;
import com.example.kishan.recyclerrrr.modelClass.markAttendanceResponse.MarkAttendanceResponse;
import com.example.kishan.recyclerrrr.retrofit.RestClient;
import com.example.kishan.recyclerrrr.utils.AttandancePrefs;
import com.example.kishan.recyclerrrr.utils.Utils;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShowAllDealerActivity extends AppCompatActivity implements DealerAdapter.OnClicklistener {
    private List<GetDealerByIdResponse> dealerList = new ArrayList<GetDealerByIdResponse>();
    private RecyclerView recyclerView;
    RelativeLayout noDelaerRL;
    Button addDealer;
    private Toolbar toolbar;

    private String mLastUpdateTime;
    private static final String TAG = ShowAllDealerActivity.class.getSimpleName();
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 10000;
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = 10000;
    private static final int REQUEST_CHECK_SETTINGS = 100;

    private FusedLocationProviderClient mFusedLocationClient;
    private SettingsClient mSettingsClient;
    private LocationRequest mLocationRequest;
    private LocationSettingsRequest mLocationSettingsRequest;
    private LocationCallback mLocationCallback;
    private Location mCurrentLocation;
    private Boolean mRequestingLocationUpdates;
    int agentId;
    private String companyId;
    private int punchValue = 0;
    private boolean attendanceMarked;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        agentId = AttandancePrefs.getInt(getApplicationContext(), "agentId", 0);
        companyId = AttandancePrefs.getString(getApplicationContext(), "companyId");
        restoreValuesFromBundle(savedInstanceState);
        punchValue = AttandancePrefs.getInt(this, "punchValue", 1);
        toolbar = (Toolbar) findViewById(R.id.toolbar1);
        noDelaerRL = findViewById(R.id.noDelaerRL);
        addDealer = findViewById(R.id.addDealer);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        addDealer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowAllDealerActivity.this, AddDealerActivity.class);
                startActivity(intent);
            }
        });

    }


    private void init() {
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mSettingsClient = LocationServices.getSettingsClient(this);
        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                mCurrentLocation = locationResult.getLastLocation();
                mLastUpdateTime = DateFormat.getTimeInstance().format(new Date());

            }
        };

        mRequestingLocationUpdates = false;
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(mLocationRequest);
        mLocationSettingsRequest = builder.build();

    }

    private void restoreValuesFromBundle(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            if (savedInstanceState.containsKey("is_requesting_updates")) {
                mRequestingLocationUpdates = savedInstanceState.getBoolean("is_requesting_updates");
            }

            if (savedInstanceState.containsKey("last_known_location")) {
                mCurrentLocation = savedInstanceState.getParcelable("last_known_location");
            }

            if (savedInstanceState.containsKey("last_updated_on")) {
                mLastUpdateTime = savedInstanceState.getString("last_updated_on");
            }

        }

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("is_requesting_updates", mRequestingLocationUpdates);
        outState.putParcelable("last_known_location", mCurrentLocation);
        outState.putString("last_updated_on", mLastUpdateTime);

    }


    private void startLocationUpdates() {
        if (mCurrentLocation != null) {
            markAttendance();
        }
        mSettingsClient
                .checkLocationSettings(mLocationSettingsRequest)
                .addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
                    @SuppressLint("MissingPermission")
                    @Override
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        Log.i(TAG, "All location settings are satisfied.");


                        mFusedLocationClient.requestLocationUpdates(mLocationRequest,
                                mLocationCallback, Looper.myLooper());


                    }
                })
                .addOnFailureListener(this, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        int statusCode = ((ApiException) e).getStatusCode();
                        switch (statusCode) {
                            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                Log.i(TAG, "GpsTracker settings are not satisfied. Attempting to upgrade " +
                                        "location settings ");
                                try {

                                    ResolvableApiException rae = (ResolvableApiException) e;
                                    rae.startResolutionForResult(ShowAllDealerActivity.this, REQUEST_CHECK_SETTINGS);
                                } catch (IntentSender.SendIntentException sie) {
                                    Log.i(TAG, "PendingIntent unable to execute request.");
                                }
                                break;
                            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                String errorMessage = "GpsTracker settings are inadequate, and cannot be " +
                                        "fixed here. Fix in Settings.";
                                Log.e(TAG, errorMessage);

                                Toast.makeText(ShowAllDealerActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                        }


                    }
                });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            // Check for the integer request code originally supplied to startResolutionForResult().
            case REQUEST_CHECK_SETTINGS:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        Log.e(TAG, "User agreed to make required location settings changes.");

                        break;
                    case Activity.RESULT_CANCELED:
                        Log.e(TAG, "User chose not to make required location settings changes.");
                        mRequestingLocationUpdates = false;
                        break;
                }
                break;
        }
    }

    public void startLocationButtonClick() {

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                        mRequestingLocationUpdates = true;
                        startLocationUpdates();
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse response) {
                        if (response.isPermanentlyDenied()) {
                            // open device settings when the permission is
                            // denied permanently
                            openSettings();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();
    }

    private void openSettings() {
        Intent intent = new Intent();
        intent.setAction(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package",
                BuildConfig.APPLICATION_ID, null);
        intent.setData(uri);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }


    @Override
    public void onResume() {
        super.onResume();
        getAllDealers();

    }

    private void getAllDealers() {
        GetDealerByIdResponse requestModel = new GetDealerByIdResponse();
        requestModel.setAgentId(agentId);
        Utils.showProgressDialog(this);
        if (Utils.isInternetConnected(this)) {
            Utils.showProgressDialog(this);
            RestClient.getAgentById(agentId, new Callback<List<GetDealerByIdResponse>>() {
                @Override
                public void onResponse(Call<List<GetDealerByIdResponse>> call, Response<List<GetDealerByIdResponse>> response) {
                    Utils.dismissProgressDialog();

                    //  Toast.makeText(ShowAllDealerActivity.this, "Success", Toast.LENGTH_SHORT).show();
                    if (response.body() != null) {
                        Log.d("First", "Done1");
                        dealerList = response.body();
                        Log.d("First", "Done2");
                        if (dealerList != null && dealerList.size() > 0) {


                            Log.d("First", "Done3");
                            DealerAdapter dealerAdapter = new DealerAdapter(getApplicationContext());
                            dealerAdapter.setdata(dealerList);
                            Log.d("First", "Done4");

                            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                            recyclerView.setLayoutManager(mLayoutManager);
                            recyclerView.setItemAnimator(new DefaultItemAnimator());
                            recyclerView.setAdapter(dealerAdapter);
                            dealerAdapter.setListener(ShowAllDealerActivity.this);
                            noDelaerRL.setVisibility(View.GONE);

                        } else {
                            noDelaerRL.setVisibility(View.VISIBLE);

                        }


                    }
                }

                @Override
                public void onFailure(Call<List<GetDealerByIdResponse>> call, Throwable t) {
                    Utils.dismissProgressDialog();
                    Toast.makeText(ShowAllDealerActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            });
        }

    }


    private boolean checkPermissions() {
        int permissionState = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        return permissionState == PackageManager.PERMISSION_GRANTED;
    }


    @Override
    protected void onPause() {
        super.onPause();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem myActionMenuItem = menu.findItem(R.id.mark_attendence);
        if (punchValue == 1) {
            myActionMenuItem.setTitle("Punch In");
        } else {
            myActionMenuItem.setTitle("Punch Out");
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        String msg = "";
        switch (item.getItemId()) {
            case R.id.add_contact:

                Intent intent = new Intent(ShowAllDealerActivity.this, AddDealerActivity.class);
                startActivity(intent);
                break;
            case R.id.mark_attendence:
                if (mCurrentLocation!=null){
                    markAttendance();
                }else{
                    startLocationButtonClick();
                }
                break;

            case R.id.logout:
                Intent logout = new Intent(ShowAllDealerActivity.this, LoginActivity.class);
                logout.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(logout);
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void markAttendance() {
        Utils.showProgressDialog(this);
        if (mCurrentLocation!=null){
            RestClient.markDealerAttendence(companyId, agentId, mCurrentLocation.getLatitude(), mCurrentLocation.getLatitude(), punchValue, new Callback<MarkAttendanceResponse>() {
                @Override
                public void onResponse(Call<MarkAttendanceResponse> call, Response<MarkAttendanceResponse> response) {
                    Utils.dismissProgressDialog();
                    if (response != null && response.body() != null) {
                        if (response.body().getResult().equalsIgnoreCase("success")) {
                            if (punchValue == 1) {
                                punchValue = 2;
                            } else {
                                punchValue = 1;
                            }
                            invalidateOptionsMenu();
                            Toast.makeText(ShowAllDealerActivity.this, "Your attendance updated successfully", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<MarkAttendanceResponse> call, Throwable t) {
                    Utils.dismissProgressDialog();
                    Toast.makeText(ShowAllDealerActivity.this, "Unable to mark attendance, please try again", Toast.LENGTH_SHORT).show();

                }
            });

        }else{
            Toast.makeText(ShowAllDealerActivity.this, "Unable to get location, please try again", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onClick(GetDealerByIdResponse getDealerByIdResponse) {
        String emailDealer = getDealerByIdResponse.getEmail();
        String firstNameDealer = getDealerByIdResponse.getFirstName();
        String mobileDealer = getDealerByIdResponse.getPhone();
        String message = getDealerByIdResponse.getMessage();


        if (TextUtils.isEmpty(getDealerByIdResponse.getFirstName())) {
            Toast.makeText(this, "Invailid Data", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, ShowDetailActivity.class);
        intent.putExtra("email", emailDealer);
        intent.putExtra("name", firstNameDealer);
        intent.putExtra("lname", getDealerByIdResponse.getLastName());
        intent.putExtra("mobile", mobileDealer);
        intent.putExtra("message", message);

        startActivity(intent);
    }
}