package com.example.kishan.recyclerrrr.utils;

public class Constants {

    public static final String ACCESS_TOKEN="assess_token";
    public static final String ACCESS_TOKEN_EMAIL="access_token_email";
    public static final String NAME ="name" ;
    public static final String EMAILID ="emailid" ;
    public static final String LoginCheck ="logincheck" ;
    public static final String Resultsubmit ="resultsubmit" ;

    public static final String UN_ATTEMPTED ="UnAttempted" ;
    public static final String ATTEMPTED ="Attempted" ;
    public static final String FREE ="Free" ;
    public static final String PAID ="Paid" ;




    public static final int CAPTURE_IMAGE =209 ;
}
